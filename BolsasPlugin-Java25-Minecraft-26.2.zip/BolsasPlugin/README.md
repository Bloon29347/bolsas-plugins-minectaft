# BolsasPlugin — Minecraft Java 26.2 / Paper / Java 25

Este proyecto está configurado para compilarse con **JDK 25** y la API de **Paper 26.2**.

## Requisitos
- JDK 25 (Java 25) o superior.
- Maven 3.9 o superior.
- Servidor Paper 26.2.
- Internet durante la primera compilación para descargar las dependencias.

## Bolsas
- Cuero: 18 espacios
- Cobre: 27 espacios
- Oro: 36 espacios
- Hierro: 45 espacios
- Diamante: 54 espacios
- Netherite: 180 espacios, con paginación en 4 páginas

## Funciones previstas
- Mejoras de bolsa mediante crafteo.
- Cambio de color con los 16 tintes vanilla.
- Inventario de bolsa persistente.

## Crear el archivo .jar
1. Instala JDK 25 y Maven.
2. Abre una terminal en la carpeta del proyecto.
3. Ejecuta `mvn clean package`.
4. Si la compilación termina correctamente, el `.jar` aparecerá en `target/BolsasPlugin-1.0.0.jar`.
5. Copia el `.jar` a la carpeta `plugins` del servidor Paper 26.2.

## Importante
Este ZIP contiene el proyecto fuente, no un `.jar` ya compilado. No se ha compilado ni probado en un servidor real en este entorno. Las texturas personalizadas necesitarían un paquete de recursos aparte.
