package com.perukistan.bolsas;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.*;

public final class BolsasPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey bagKey, tierKey, colorKey;
    private final Map<UUID, UUID> openBags = new HashMap<>();
    private final Map<UUID, Inventory> openInventories = new HashMap<>();
    private final Map<UUID, Integer> pages = new HashMap<>();

    private static final int PAGE_SIZE = 45;
    private static final int LARGE_BAG_SLOTS = 64;
    private static final LinkedHashMap<String, Tier> TIERS = new LinkedHashMap<>();
    private static final List<Material> DYES = List.of(
        Material.WHITE_DYE, Material.ORANGE_DYE, Material.MAGENTA_DYE, Material.LIGHT_BLUE_DYE,
        Material.YELLOW_DYE, Material.LIME_DYE, Material.PINK_DYE, Material.GRAY_DYE,
        Material.LIGHT_GRAY_DYE, Material.CYAN_DYE, Material.PURPLE_DYE, Material.BLUE_DYE,
        Material.BROWN_DYE, Material.GREEN_DYE, Material.RED_DYE, Material.BLACK_DYE
    );
    static {
        TIERS.put("cuero", new Tier(Material.LEATHER, "Cuero", 8));
        TIERS.put("cobre", new Tier(Material.COPPER_INGOT, "Cobre", 17));
        TIERS.put("oro", new Tier(Material.GOLD_INGOT, "Oro", 24));
        TIERS.put("hierro", new Tier(Material.IRON_INGOT, "Hierro", 35));
        TIERS.put("diamante", new Tier(Material.DIAMOND, "Diamante", 54));
        TIERS.put("netherite", new Tier(Material.NETHERITE_INGOT, "Netherite", 72));
    }
    private record Tier(Material material, String label, int slots) {}

    @Override public void onEnable() {
        bagKey = new NamespacedKey(this, "bag_id");
        tierKey = new NamespacedKey(this, "bag_tier");
        colorKey = new NamespacedKey(this, "bag_color");
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("bolsa")).setExecutor(this);
        File data = new File(getDataFolder(), "bags");
        if (!data.exists()) data.mkdirs();
        registerRecipes();
        getLogger().info("BolsasPlugin activado.");
    }

    private void registerRecipes() {
        // Bolsa inicial: 8 cueros alrededor de un cofre.
        NamespacedKey leatherKey = new NamespacedKey(this, "bolsa_cuero");
        Bukkit.removeRecipe(leatherKey);
        ShapelessRecipe leatherRecipe = new ShapelessRecipe(leatherKey, new ItemStack(Material.LEATHER));
        leatherRecipe.addIngredient(Material.CHEST);
        for (int i = 0; i < 8; i++) leatherRecipe.addIngredient(Material.LEATHER);
        Bukkit.addRecipe(leatherRecipe);
        // Las mejoras se validan y personalizan en PrepareItemCraftEvent.
        registerShapeless("upgrade_cobre", Material.LEATHER, Material.COPPER_INGOT, 4);
        registerShapeless("upgrade_oro", Material.LEATHER, Material.GOLD_INGOT, 4);
        registerShapeless("upgrade_hierro", Material.LEATHER, Material.IRON_INGOT, 4);
        registerShapeless("upgrade_diamante", Material.LEATHER, Material.DIAMOND, 4);
        registerShapeless("upgrade_netherite", Material.LEATHER, Material.NETHERITE_INGOT, 4);
        for (Material dye : DYES) {
            NamespacedKey key = new NamespacedKey(this, "tinte_" + dye.name().toLowerCase(Locale.ROOT));
            Bukkit.removeRecipe(key);
            ShapelessRecipe recipe = new ShapelessRecipe(key, new ItemStack(Material.LEATHER));
            recipe.addIngredient(Material.LEATHER);
            recipe.addIngredient(dye);
            Bukkit.addRecipe(recipe);
        }
    }
    private void registerShapeless(String name, Material base, Material material, int amount) {
        NamespacedKey key = new NamespacedKey(this, name);
        Bukkit.removeRecipe(key);
        ShapelessRecipe recipe = new ShapelessRecipe(key, new ItemStack(base));
        recipe.addIngredient(base);
        for (int i = 0; i < amount; i++) recipe.addIngredient(material);
        Bukkit.addRecipe(recipe);
    }

    private boolean isBag(ItemStack item) {
        return item != null && item.hasItemMeta()
            && item.getItemMeta().getPersistentDataContainer().has(bagKey, PersistentDataType.STRING);
    }
    private UUID bagId(ItemStack item) {
        try { return UUID.fromString(item.getItemMeta().getPersistentDataContainer().get(bagKey, PersistentDataType.STRING)); }
        catch (Exception ex) { return null; }
    }
    private String tierId(ItemStack item) {
        String value = item.getItemMeta().getPersistentDataContainer().get(tierKey, PersistentDataType.STRING);
        return value == null ? "cuero" : value;
    }
    private String bagColor(ItemStack item) {
        String value = item.getItemMeta().getPersistentDataContainer().get(colorKey, PersistentDataType.STRING);
        return value == null ? "BROWN" : value;
    }
    private Tier tier(ItemStack item) { return TIERS.getOrDefault(tierId(item), TIERS.get("cuero")); }
    private int capacity(ItemStack item) { return tier(item).slots(); }

    private ItemStack createBag(String level) {
        Tier t = TIERS.getOrDefault(level.toLowerCase(Locale.ROOT), TIERS.get("cuero"));
        ItemStack item = new ItemStack(Material.LEATHER);
        ItemMeta meta = item.getItemMeta();
        UUID id = UUID.randomUUID();
        meta.getPersistentDataContainer().set(bagKey, PersistentDataType.STRING, id.toString());
        meta.getPersistentDataContainer().set(tierKey, PersistentDataType.STRING, level.toLowerCase(Locale.ROOT));
        meta.getPersistentDataContainer().set(colorKey, PersistentDataType.STRING, "BROWN");
        meta.setDisplayName(ChatColor.GOLD + "Bolsa de " + t.label());
        meta.setLore(List.of(ChatColor.GRAY + "Espacios: " + capacityForLevel(level),
            ChatColor.GRAY + "Color: Marrón", ChatColor.YELLOW + "Clic derecho para abrir",
            ChatColor.DARK_GRAY + "Mejora y cambia el color en la mesa de crafteo."));
        item.setItemMeta(meta);
        saveContents(id, new ItemStack[capacityForLevel(level)]);
        return item;
    }
    private int capacityForLevel(String level) {
        Tier t = TIERS.getOrDefault(level, TIERS.get("cuero"));
        return t.slots();
    }
    private void updateBag(ItemStack item, String level, String color) {
        if (!isBag(item)) return;
        Tier t = TIERS.getOrDefault(level, TIERS.get("cuero"));
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(tierKey, PersistentDataType.STRING, level);
        meta.getPersistentDataContainer().set(colorKey, PersistentDataType.STRING, color);
        meta.setDisplayName(ChatColor.GOLD + "Bolsa de " + t.label() + " " + colorName(color));
        meta.setLore(List.of(ChatColor.GRAY + "Espacios: " + capacityForLevel(level),
            ChatColor.GRAY + "Color: " + colorName(color),
            ChatColor.YELLOW + "Clic derecho para abrir",
            ChatColor.DARK_GRAY + "Mejora y cambia el color en la mesa de crafteo."));
        item.setItemMeta(meta);
    }
    private String colorName(String c) {
        return switch (c) {
            case "RED" -> "Rojo"; case "ORANGE" -> "Naranja"; case "YELLOW" -> "Amarillo";
            case "LIME" -> "Verde lima"; case "GREEN" -> "Verde"; case "CYAN" -> "Cian";
            case "LIGHT_BLUE" -> "Celeste"; case "BLUE" -> "Azul"; case "PURPLE" -> "Morado";
            case "MAGENTA" -> "Magenta"; case "PINK" -> "Rosa"; case "WHITE" -> "Blanco";
            case "BLACK" -> "Negro"; case "GRAY" -> "Gris"; case "LIGHT_GRAY" -> "Gris claro";
            case "BROWN" -> "Marrón"; default -> "Marrón";
        };
    }
    private String dyeName(Material m) {
        String n = m.name();
        return n.endsWith("_DYE") ? n.substring(0, n.length() - 4) : null;
    }

    private File dataFile(UUID id) { return new File(new File(getDataFolder(), "bags"), id + ".yml"); }
    private void saveContents(UUID id, ItemStack[] contents) {
        if (id == null) return;
        org.bukkit.configuration.file.YamlConfiguration y = new org.bukkit.configuration.file.YamlConfiguration();
        y.set("contents", contents);
        try { y.save(dataFile(id)); } catch (Exception e) { getLogger().warning("No se pudo guardar bolsa " + id); }
    }
    private ItemStack[] loadContents(UUID id, int size) {
        ItemStack[] result = new ItemStack[size];
        if (id == null) return result;
        File f = dataFile(id);
        if (!f.exists()) return result;
        org.bukkit.configuration.file.YamlConfiguration y = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(f);
        List<?> raw = y.getList("contents", List.of());
        for (int i = 0; i < Math.min(size, raw.size()); i++) {
            Object o = raw.get(i);
            if (o instanceof ItemStack stack) result[i] = stack;
        }
        return result;
    }

    private ItemStack button(Material mat, String name) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta(); meta.setDisplayName(name); item.setItemMeta(meta);
        return item;
    }
    private Inventory makeView(UUID id, ItemStack bag, int page) {
        int slots = capacity(bag);
        boolean paginated = slots > PAGE_SIZE;
        int pageCount = (int) Math.ceil(slots / (double) PAGE_SIZE);
        int size = paginated ? 54 : Math.max(9, ((slots + 8) / 9) * 9);
        Inventory inv = Bukkit.createInventory(null, size,
            ChatColor.DARK_GRAY + "Bolsa: " + tier(bag).label() + (paginated ? " (" + (page + 1) + "/" + pageCount + ")" : ""));
        ItemStack[] all = loadContents(id, slots);
        if (paginated) {
            int start = page * PAGE_SIZE;
            for (int i = 0; i < PAGE_SIZE && start + i < all.length; i++) inv.setItem(i, all[start + i]);
            inv.setItem(45, button(Material.ARROW, ChatColor.YELLOW + "Página anterior"));
            inv.setItem(49, button(Material.PAPER, ChatColor.GRAY + "Página " + (page + 1) + " de " + pageCount));
            inv.setItem(53, button(Material.ARROW, ChatColor.YELLOW + "Página siguiente"));
        } else {
            for (int i = 0; i < all.length; i++) inv.setItem(i, all[i]);
        }
        return inv;
    }
    private void saveView(Player player, Inventory inv) {
        UUID id = openBags.get(player.getUniqueId());
        if (id == null || inv == null) return;
        ItemStack bag = findBag(player, id);
        int size = bag == null ? LARGE_BAG_SLOTS : capacity(bag);
        ItemStack[] all = loadContents(id, size);
        boolean paginatedView = inv.getSize() == 54 && inv.getItem(49) != null && inv.getItem(49).getType() == Material.PAPER;
        if (paginatedView) {
            int start = pages.getOrDefault(player.getUniqueId(), 0) * PAGE_SIZE;
            for (int i = 0; i < PAGE_SIZE && start + i < all.length; i++) all[start + i] = inv.getItem(i);
        } else {
            for (int i = 0; i < inv.getSize() && i < all.length; i++) all[i] = inv.getItem(i);
        }
        saveContents(id, all);
    }
    private ItemStack findBag(Player player, UUID id) {
        for (ItemStack item : player.getInventory().getContents())
            if (isBag(item) && id.equals(bagId(item))) return item;
        return null;
    }
    private void openBag(Player player, ItemStack bag, int page) {
        UUID id = bagId(bag);
        if (id == null) return;
        Inventory inv = makeView(id, bag, page);
        // Guardar la vista anterior antes de cambiar de página.
        Inventory previous = openInventories.get(player.getUniqueId());
        if (previous != null) saveView(player, previous);
        openBags.put(player.getUniqueId(), id);
        openInventories.put(player.getUniqueId(), inv);
        pages.put(player.getUniqueId(), page);
        player.openInventory(inv);
    }

    @EventHandler public void onInteract(PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        if (isBag(item) && event.getAction().isRightClick()) {
            event.setCancelled(true);
            openBag(event.getPlayer(), item, 0);
        }
    }

    private String nextTier(String current) {
        return switch (current) {
            case "cuero" -> "cobre"; case "cobre" -> "oro"; case "oro" -> "hierro";
            case "hierro" -> "diamante"; case "diamante" -> "netherite"; default -> null;
        };
    }
    private Material upgradeMaterial(String next) {
        return switch (next) {
            case "cobre" -> Material.COPPER_INGOT; case "oro" -> Material.GOLD_INGOT;
            case "hierro" -> Material.IRON_INGOT; case "diamante" -> Material.DIAMOND;
            case "netherite" -> Material.NETHERITE_INGOT; default -> null;
        };
    }

    @EventHandler public void onPrepareCraft(PrepareItemCraftEvent event) {
        ItemStack[] matrix = event.getInventory().getMatrix();
        ItemStack bag = null; int bags = 0; Material dye = null; int dyeCount = 0;
        Map<Material, Integer> counts = new HashMap<>();
        for (ItemStack item : matrix) {
            if (isBag(item)) { bag = item; bags++; }
            else if (item != null && !item.getType().isAir()) {
                counts.merge(item.getType(), item.getAmount(), Integer::sum);
                if (DYES.contains(item.getType())) { dye = item.getType(); dyeCount += item.getAmount(); }
            }
        }
        if (bags == 0) {
            // Receta de bolsa de cuero: un cofre y ocho cueros.
            if (counts.size() == 2 && counts.getOrDefault(Material.CHEST, 0) == 1
                    && counts.getOrDefault(Material.LEATHER, 0) == 8) {
                event.getInventory().setResult(createBag("cuero"));
            }
            return;
        }
        if (bags != 1 || bag == null) { event.getInventory().setResult(null); return; }

        // Cambio de color: bolsa + exactamente un tinte.
        if (dye != null && counts.size() == 1 && dyeCount == 1) {
            ItemStack result = bag.clone(); result.setAmount(1);
            updateBag(result, tierId(bag), dyeName(dye));
            event.getInventory().setResult(result);
            return;
        }

        String next = nextTier(tierId(bag));
        if (next == null) { event.getInventory().setResult(null); return; }
        Material required = upgradeMaterial(next);
        int total = 0; boolean onlyRequired = true;
        for (Map.Entry<Material, Integer> e : counts.entrySet()) {
            if (e.getKey() != required) onlyRequired = false;
            total += e.getValue();
        }
        if (!onlyRequired || total != 4) { event.getInventory().setResult(null); return; }
        ItemStack result = bag.clone(); result.setAmount(1);
        updateBag(result, next, bagColor(bag));
        event.getInventory().setResult(result);
    }

    @EventHandler public void onCraft(CraftItemEvent event) {
        ItemStack result = event.getCurrentItem();
        if (!isBag(result)) return;
        ItemStack oldBag = null;
        for (ItemStack item : event.getInventory().getMatrix()) if (isBag(item)) { oldBag = item; break; }
        // La receta inicial crea una bolsa nueva; su identificador ya está en el resultado.
        if (oldBag == null) return;
        UUID id = bagId(oldBag);
        if (id == null) { event.setCancelled(true); return; }
        ItemStack[] oldContents = loadContents(id, capacity(oldBag));
        ItemStack output = result.clone();
        ItemMeta meta = output.getItemMeta();
        meta.getPersistentDataContainer().set(bagKey, PersistentDataType.STRING, id.toString());
        output.setItemMeta(meta);
        event.setCurrentItem(output);
        Bukkit.getScheduler().runTask(this, () -> {
            ItemStack cursor = ((Player) event.getWhoClicked()).getItemOnCursor();
            if (isBag(cursor)) {
                ItemMeta cursorMeta = cursor.getItemMeta();
                cursorMeta.getPersistentDataContainer().set(bagKey, PersistentDataType.STRING, id.toString());
                cursor.setItemMeta(cursorMeta);
                ((Player) event.getWhoClicked()).setItemOnCursor(cursor);
                saveContents(id, Arrays.copyOf(oldContents, capacity(cursor)));
            }
        });
    }

    @EventHandler public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        UUID id = openBags.get(player.getUniqueId());
        Inventory top = openInventories.get(player.getUniqueId());
        if (id == null || top == null || event.getView().getTopInventory() != top) return;

        ItemStack clicked = event.getCurrentItem();
        ItemStack ownedBag = findBag(player, id);
        if (ownedBag != null && event.getClickedInventory() == top && capacity(ownedBag) <= PAGE_SIZE
                && event.getRawSlot() >= capacity(ownedBag)) {
            event.setCancelled(true);
            return;
        }
        if (ownedBag != null && capacity(ownedBag) > PAGE_SIZE && event.getClickedInventory() == top) {
            int raw = event.getRawSlot();
            if (raw == 45 || raw == 53) {
                event.setCancelled(true);
                saveView(player, top);
                ItemStack bag = findBag(player, id);
                if (bag != null) {
                    int pageCount = (int) Math.ceil(capacity(bag) / (double) PAGE_SIZE);
                    int page = Math.max(0, Math.min(pageCount - 1, pages.getOrDefault(player.getUniqueId(), 0) + (raw == 53 ? 1 : -1)));
                    openBag(player, bag, page);
                }
                return;
            }
            if (raw >= 45) { event.setCancelled(true); return; }
        }
        if (event.getClickedInventory() == top && isBag(clicked)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "No puedes guardar una bolsa dentro de otra.");
        }
    }

    @EventHandler public void onDrag(InventoryDragEvent event) {
        Player player = (Player) event.getWhoClicked();
        Inventory top = openInventories.get(player.getUniqueId());
        if (top == null || event.getView().getTopInventory() != top) return;
        ItemStack ownedBag = findBag(player, openBags.get(player.getUniqueId()));
        int capacity = ownedBag == null ? top.getSize() : capacity(ownedBag);
        for (int raw : event.getRawSlots()) {
            if (raw < top.getSize() && isBag(event.getOldCursor())) { event.setCancelled(true); return; }
            if (top.getSize() == 54 && raw >= 45 && raw < 54) { event.setCancelled(true); return; }
            if (capacity <= PAGE_SIZE && raw < top.getSize() && raw >= capacity) { event.setCancelled(true); return; }
        }
    }
    @EventHandler public void onClose(InventoryCloseEvent event) {
        Player player = (Player) event.getPlayer();
        Inventory inv = event.getInventory();
        if (inv != openInventories.get(player.getUniqueId())) return;
        saveView(player, inv);
        openBags.remove(player.getUniqueId()); openInventories.remove(player.getUniqueId()); pages.remove(player.getUniqueId());
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("ayuda")) {
            sender.sendMessage(ChatColor.GOLD + "Bolsas: cuero 8, cobre 17, oro 24, hierro 35, diamante 54, netherite 72 espacios.");
            sender.sendMessage(ChatColor.YELLOW + "Bolsa de cuero: 8 cueros + 1 cofre. Mejoras: bolsa + 4 unidades del siguiente material.");
            sender.sendMessage(ChatColor.YELLOW + "Color en mesa: bolsa + 1 tinte del color deseado.");
            sender.sendMessage(ChatColor.GRAY + "/bolsa dar <jugador> <cuero|cobre|oro|hierro|diamante|netherite>");
            return true;
        }
        if (args[0].equalsIgnoreCase("dar")) {
            if (!sender.hasPermission("bolsas.admin") || args.length < 3) return false;
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage("Jugador no conectado."); return true; }
            String level = args[2].toLowerCase(Locale.ROOT);
            if (!TIERS.containsKey(level)) { sender.sendMessage("Nivel inválido."); return true; }
            target.getInventory().addItem(createBag(level)).values().forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
            sender.sendMessage(ChatColor.GREEN + "Bolsa entregada a " + target.getName() + ".");
            return true;
        }
        sender.sendMessage("Usa /bolsa ayuda.");
        return true;
    }
}
